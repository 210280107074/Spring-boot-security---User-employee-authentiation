package com.user_employee.user_employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
