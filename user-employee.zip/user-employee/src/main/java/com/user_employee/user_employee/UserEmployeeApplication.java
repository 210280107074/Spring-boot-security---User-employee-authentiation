package com.user_employee.user_employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserEmployeeApplication.class, args);
	}

}
